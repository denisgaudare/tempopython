# PhysiJSON – Analyse Scientifique NDJSON

Voir `src/physijson/` pour le code source.
