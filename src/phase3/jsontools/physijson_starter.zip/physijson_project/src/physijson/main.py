import json
import ijson
from jsonschema import validate, ValidationError

def validate_ndjson(file_path, schema_path):
    with open(schema_path) as f:
        schema = json.load(f)

    with open(file_path) as f:
        for line in f:
            try:
                record = json.loads(line)
                validate(instance=record, schema=schema)
                print(f"✔ Valid: {record['id']}")
            except ValidationError as e:
                print(f"✘ Invalid: {e.message}")

if __name__ == "__main__":
    validate_ndjson("data/experiments.ndjson", "schemas/experiment.schema.json")
